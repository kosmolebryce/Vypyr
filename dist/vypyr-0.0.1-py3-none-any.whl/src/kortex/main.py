# main.py
import json
import os
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path as p
from vypyr.src import medulla
from medulla.main import *

import click

from .gui import main as gui_main

# GLOBAL CONTROLLERS
HOME = p.home()
WORKSPACES_DIR = HOME / "workspaces"
VYPYR_DIR = WORKSPACES_DIR / "vypyr"
SRC_DIR = VYPYR_DIR / "src"
KORTEX_DIR = SRC_DIR / "kortex"
LOGS_DIR = KORTEX_DIR / "logs"
DATA_PATH = KORTEX_DIR / "data.json"
DATA_DIR = KORTEX_DIR / "data"

PRINT_SPEED = 0.001  # in seconds

TAX_RATE = 0.27  # 27% tax rate

# ASCII Art Title for each menu section
TITLE_CARD = {
    "Title": """
              ╔═══════════════════╗
              ║╔═╗╔═╗╦═╗╔╦╗╔═╗═╗ ╦║
              ║║  ║ ║╠╦╝ ║ ║╣ ╔╩╦╝║
              ║╚═╝╚═╝╩╚═ ╩ ╚═╝╩ ╚═║
              ╚═══════════════════╝
              [T I M E K E E P E R]
    """
}


# UTILITIES AND HELPER FUNCTIONS
def title():
    clear_screen()
    div()
    print(TITLE_CARD["Title"])  # ASCII Art Title
    div()
    print_blank_lines()


def print_blank_lines(num_lines=3):
    for _ in range(num_lines):
        print()


def wait(duration=PRINT_SPEED):
    time.sleep(duration)


def clear_screen():
    # Check if running in Pyto
    if "pyto" in sys.modules:
        # Pyto specific screen clearing
        print("\033[H\033[J")
    else:
        # Standard screen clearing for other environments
        os.system("cls" if os.name == "nt" else "clear")


def initialize():
    cd(f"{KORTEX_DIR}")
    if not os.path.exists("data.json"):
        with open("data.json", "w") as f:
            data = {"data": {}}
            json.dump(data, f)
    else:
        with open("data.json", "r+") as f:
            data = json.load(f)


def typyr(text):
    for char in text:
        print(char, end="", flush=True)
        wait(PRINT_SPEED)


def validate_date(ctx, param, value):
    try:
        if value.lower() == "a":
            ctx.abort()
        return datetime.strptime(value, "%Y-%m-%d").date()
    except ValueError:
        raise click.BadParameter("Date must be in YYYY-MM-DD format")


def validate_time(ctx, param, value):
    try:
        if value.lower() == "a":
            ctx.abort()
        return datetime.strptime(value, "%H:%M").time()
    except ValueError:
        raise click.BadParameter("Time must be in HH:MM format")


def print_param_headers():
    header_shift_id = "SHIFT #"
    header_param = "PARAMETER"
    header_value = "VALUE"
    max_param_length = max(len(header_shift_id), len(header_param), len(header_value))
    total_length = 64
    param_width = min(
        max_param_length, (total_length - 14) // 2
    )  # Considering space for "Shift ID" and delimiters
    value_width = (
        total_length - 14 - param_width
    )  # Remaining space for "Value" after considering "Shift ID" and delimiters
    header_shift_id_formatted = f"{header_shift_id:<8}"
    header_param_formatted = f"{header_param:<{param_width}}"
    header_value_formatted = f"{header_value:<{value_width}}"
    print(
        f"{header_shift_id_formatted} | {header_param_formatted} {' ' * 4} | {header_value_formatted}"
    )


def print_shift_values(shift_id, shift):
    max_param_length = max(len(param) for param in shift)
    first_row = True
    for param, value in shift.items():
        if first_row:
            print(f"{shift_id:<8} | {param:<{max_param_length}} | {value}")
            first_row = False
        else:
            print(f"{'':<8} | {param:<{max_param_length}} | {value}")


def abort_if_a(value):
    """Custom validator that aborts if the input is 'a'."""
    if value.lower() == "a":
        raise click.Abort()
    return value


def prompt_with_abort(prompt_text, type=None, value_proc=None):
    """Prompts the user and allows aborting with 'a'."""
    while True:
        value = click.prompt(prompt_text, type=type, value_proc=value_proc)
        try:
            if value_proc:
                value = value_proc(value)
            break
        except click.Abort:
            raise
        except Exception as e:
            click.echo(f"Error: {e}")
    return value


def validate_currency(ctx, param, value):
    try:
        # Convert input to a float and ensure it's non-negative
        value = float(value)
        if value < 0:
            raise ValueError
    except ValueError:
        raise click.BadParameter("the value must be a positive number")
    return value


# `click` GROUPS AND COMMANDS
@click.group()
def cli():
    """KORTEX is a time-tracking CLI for managing contract service records."""
    pass


@click.group()
def record():
    """Group for record commands."""
    pass


@record.command(help="Add a new record with automatic entry.")
def auto():
    """Handles automatic entry for a new record."""
    # Boilerplate
    cd(f"{KORTEX_DIR}")
    title()
    typyr("[NEW RECORD - Automatic Entry]\n\n")
    typyr("Enter 'a' at any time to abort.\n\n")

    # Load existing data
    with open(f"{DATA_PATH}", "r+") as f:
        data = json.load(f)

        id_proc = lambda x: abort_if_a(x) or x.upper()
        model_id = prompt_with_abort("Model ID", value_proc=id_proc).upper()
        project_id = prompt_with_abort("Project ID", value_proc=id_proc).upper()

        pay_rate = float(
            prompt_with_abort("Hourly rate of pay", type=float, value_proc=abort_if_a)
        )

        current_datetime_start = datetime.now()
        shift_date_str = current_datetime_start.strftime("%Y-%m-%d")
        shift_in_str = current_datetime_start.strftime("%H:%M")

        # Using 'nano' as the fallback editor
        default_editor = os.environ.get("EDITOR", "nano")
        shift_id = str(len(data["data"]) + 1).zfill(3)
        cd(f"{LOGS_DIR}")

        with open(f"{shift_id}.log", "w+") as log:
            log.write(f"Shift ID:   {shift_id}\n")
            log.write(f"Model ID:   {model_id}\n")
            log.write(f"Proj. ID:   {project_id}\n")
            log.write(f"══════════════════════════════════════════════\n")
            log.flush()
            subprocess.run([default_editor, f"{shift_id}.log"], text=True)

        cd(f"{KORTEX_DIR}")

        current_datetime_end = datetime.now()
        shift_out_str = current_datetime_end.strftime("%H:%M")

        shift_in = datetime.strptime(
            f"{shift_date_str} {shift_in_str}", "%Y-%m-%d %H:%M"
        )
        shift_out = datetime.strptime(
            f"{shift_date_str} {shift_out_str}", "%Y-%m-%d %H:%M"
        )

        # Calculate shift duration in minutes and convert to hours
        shift_dur_minutes = (shift_out - shift_in).total_seconds() // 60
        shift_dur_hours = shift_dur_minutes / 60

        pay_gross = shift_dur_hours * pay_rate

        shift = {
            "Date": shift_date_str,
            "In (hh:mm)": shift_in_str,
            "Out (hh:mm)": shift_out_str,
            "Model ID": model_id,
            "Project ID": project_id,
            "Hourly pay": "{:.2f}".format(pay_rate),
            "Duration (hrs)": "{:.2f}".format(shift_dur_hours),
            "Gross pay": "{:.2f}".format(pay_gross),
        }

        # Dump `shift` dictionary to `data.json`
        data["data"][shift_id] = shift
        f.seek(0)
        json.dump(data, f, indent=4)
        f.truncate()
    print_blank_lines()
    div()
    typyr("\nAdded shift.\n")
    click.pause()
    

@record.command(help="Add a new record with manual entry.")
def manual():
    """Handles manual entry for a new record."""
    while True:
        cd(f"{KORTEX_DIR}")
        title()
        date_proc = lambda x: abort_if_a(x) or click.DateTime(formats=["%Y-%m-%d"])(x)
        time_proc = lambda x: abort_if_a(x) or click.DateTime(formats=["%H:%M"])(x)
        shift_date_str = prompt_with_abort(
            "Date of record (yyyy-mm-dd)", value_proc=date_proc
        )
        shift_in_str = prompt_with_abort("Time in (hh:mm)", value_proc=time_proc)
        shift_out_str = prompt_with_abort("Time out (hh:mm)", value_proc=time_proc)

        id_proc = lambda x: abort_if_a(x) or x.upper()
        model_id = prompt_with_abort("Model ID", value_proc=id_proc).upper()
        project_id = prompt_with_abort("Project ID", value_proc=id_proc).upper()

        pay_rate = float(
            prompt_with_abort("Hourly rate of pay", type=float, value_proc=abort_if_a)
        )

        # Convert the input strings to datetime objects
        shift_date = datetime.strptime(shift_date_str, "%Y-%m-%d")
        shift_in = datetime.strptime(shift_in_str, "%H:%M")
        shift_out = datetime.strptime(shift_out_str, "%H:%M")

        # Assuming 'shift_in' and 'shift_out' are datetime objects representing the start and end times
        shift_dur_seconds = (shift_out - shift_in).total_seconds()
        shift_dur = shift_dur_seconds / 3600.0

        # print(f"shift_dur type: {type(shift_dur)}, value: {shift_dur}")
        # print(f"pay_rate type: {type(pay_rate)}, value: {pay_rate}")

        # Assuming 'pay_rate' is a float representing the hourly rate
        pay_gross = shift_dur * pay_rate

        click.echo("\nYou entered:")
        click.echo(f"\n> Date: {shift_date.strftime('%Y-%m-%d')}")
        click.echo(f"> Time in: {shift_in.strftime('%H:%M')}")
        click.echo(f"> Time out: {shift_out.strftime('%H:%M')}")
        click.echo(f"> Model ID: {model_id}")
        click.echo(f"> Project ID: {project_id}")
        click.echo(f"> Hourly pay: ${'{:.2f}'.format(pay_rate)}\n")

        if click.confirm("Is this information correct?", default=True):
            with open(f"{DATA_PATH}", "r+") as f:
                data = json.load(f)
                shift_id = str(len(data["data"]) + 1).zfill(3)
                shift = {
                    "Date": shift_date.strftime("%Y-%m-%d"),
                    "In (hh:mm)": shift_in.strftime("%H:%M"),
                    "Out (hh:mm)": shift_out.strftime("%H:%M"),
                    "Model ID": model_id,
                    "Project ID": project_id,
                    "Hourly pay": "{:.2f}".format(pay_rate),
                    "Duration (hrs)": "{:.2f}".format(shift_dur),
                    "Gross pay": "{:.2f}".format(pay_gross),
                }
                data["data"][shift_id] = shift
                f.seek(0)
                json.dump(data, f, indent=4)
                f.truncate()
            typyr("Added shift.\n")

            if not click.confirm("Would you like to log another shift?", default=False):
                break

            else:
                div()
                print_blank_lines()
        else:
            typyr("Entry discarded. Starting over...\n")
    


@click.group()
def view():
    """Group for viewing records commands."""
    pass
    


@view.command(help="View all records.")
def all():
    """View all shift records."""
    title()
    typyr("[VIEW ALL RECORDS]")
    print_blank_lines()

    try:
        with open(f"{DATA_PATH}", "r") as f:
            data = json.load(f)
            if not data["data"]:
                typyr("No shift records found.")
                return
            print_param_headers()
            div()
            for shift_id, shift in data["data"].items():
                print_shift_values(shift_id, shift)
                div()
    except Exception as e:
        typyr(f"An error occurred: {e}")

    click.pause()
    clear_screen()
    
    

@view.command(help="View records for a specific month. Feature not implemented.")
def month():
    """Placeholder for viewing records by month."""
    div()
    typyr("This feature has not yet been implemented.\n")
    click.pause()
    


@view.command(help="View records for a specific year. Feature not implemented.")
def year():
    """Placeholder for viewing records by year."""
    div()
    typyr("This feature has not yet been implemented.\n")
    click.pause()
    
    

@view.command(help="View the logfile for a specified record.")
def logs():
    """View the logfile for a specified shift record."""
    title()
    cd(f"{KORTEX_DIR}")
    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
            if not data["data"]:
                typyr("No shift records found.")
                click.pause(info="\nPress any key to continue...")
                clear_screen()
                return
        
        typyr("[VIEW LOGFILE]\n\n")
        for shift_id, shift in data["data"].items():
            click.echo(
                f"{shift_id}: {shift['Date']} - {shift['In (hh:mm)']} to {shift['Out (hh:mm)']}"
            )
            wait()
        div()
        shift_id = prompt_with_abort(
            "Enter the ID of the logfile to view", type=str, value_proc=abort_if_a
        )
        div()

        if shift_id in data["data"]:
            cd(LOGS_DIR)
            with open(f"{shift_id}.log", "r") as f:
                lines = f.readlines()
                for line in lines:
                    print(line)
                    wait()
                div()
        else:
            typyr("Invalid shift ID.")

        click.pause(info="\nPress any key to continue...")
        clear_screen()

    except Exception as e:
        typyr(f"An error occurred: {str(e)}")
        
    return cd(f"{KORTEX_DIR}")


@click.command(help="Delete a shift record.")
def delete():
    """Delete a specific shift record."""
    title()
    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
        if not data["data"]:
            typyr("No shift records found.")
            click.pause(info="\nPress any key to continue...")
            clear_screen()
            return
        typyr("[DELETE RECORD]\n\n")
        for shift_id, shift in data["data"].items():
            click.echo(
                f"{shift_id}: {shift['Date']} - {shift['In (hh:mm)']} to {shift['Out (hh:mm)']}"
            )
            wait()
        div()
        shift_id = prompt_with_abort(
            "Enter the ID of the shift to delete", type=str, value_proc=abort_if_a
        )

        if shift_id in data["data"]:
            del data["data"][shift_id]
            with open(DATA_PATH, "w") as f:
                json.dump(data, f, indent=4)
            cd(LOGS_DIR)

            typyr(f"\nDeleting associated logfile '{shift_id}.log'...")
            wait(1)
            if os.path.exists(f"{shift_id}.log"):
                os.remove(f"{shift_id}.log")
                typyr("\nDeleted.")
                wait(1)
            else:
                typyr("\nNo associated logfile found...")
                wait(1)
            typyr("\nShift deleted successfully.")
            wait(1)
        else:
            typyr("\nInvalid shift ID.")

    except Exception as e:
        typyr(f"\nAn error occurred: {str(e)}")

    click.pause(info="\nPress any key to continue...")
    clear_screen()
    


@click.command(help="Show running totals.")
def totals():
    """Display running data totals."""
    title()
    typyr("[RUNNING TOTALS]\n")
    print_blank_lines()

    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
            if not data["data"]:
                click.echo("No data to display.")
                return

            total_hours = round(
                sum(float(shift["Duration (hrs)"]) for shift in data["data"].values()),
                2,
            )
            total_shifts = len(data["data"])
            total_gross_pay = round(
                sum(float(shift["Gross pay"]) for shift in data["data"].values()), 2
            )

            est_tax_liability = total_gross_pay * TAX_RATE
            est_net_income = total_gross_pay - est_tax_liability

            click.echo(f"{'TOTAL SHIFTS WORKED':<30} | {total_shifts}")
            time.sleep(0.01)  # Replacing wait with time.sleep for clarity
            click.echo(f"{'TOTAL GROSS PAY':<30} | ${'{:.2f}'.format(total_gross_pay)}")
            time.sleep(0.01)
            click.echo(f"{'TOTAL HOURS WORKED':<30} | {total_hours}")
            time.sleep(0.01)
            click.echo(
                f"{'EST. TAX LIABILITY':<30} | ${'{:.2f}'.format(est_tax_liability)}"
            )
            time.sleep(0.01)
            click.echo(f"{'EST. NET INCOME':<30} | ${'{:.2f}'.format(est_net_income)}")
            time.sleep(0.01)
    except Exception as e:
        click.echo(f"An error occurred: {e}")

    print_blank_lines()
    div()
    click.pause(info="\nPress any key to continue...")
    
    

@click.command(help="Edit a specific record.")
def edit():
    """Change the values of service record parameters."""
    title()
    try:
        with open(DATA_PATH, "r") as f:
            data = json.load(f)
            if not data["data"]:
                click.echo("No records found.")
                return
            typyr("[ALL SHIFTS]\n\n")
            for shift_id, shift in data["data"].items():
                click.echo(
                    f"{shift_id}: {shift['Date']} - {shift['In (hh:mm)']} to {shift['Out (hh:mm)']}"
                )
                wait()
            div()

        print_blank_lines()
        shift_id = click.prompt("Enter the ID of the shift to be edited", type=str)

        if shift_id in data["data"]:
            shift = data["data"][shift_id]
            click.echo("[SHIFT RECORDS]\n")
            div()
            print_blank_lines()
            for i, (key, value) in enumerate(shift.items(), start=1):
                click.echo(f"{i}. {key}: {value}")
                time.sleep(0.01)

            parameter_choice = click.prompt("Select a record to update (#)", type=int)
            parameter_to_edit = list(shift.keys())[parameter_choice - 1]
            click.echo(
                f"\nSHIFT #{shift_id} {parameter_to_edit} is currently: {shift[parameter_to_edit]}"
            )
            new_value = click.prompt(
                f"Enter the new value for {parameter_to_edit}", type=str
            ).upper()
            shift[parameter_to_edit] = new_value

            with open(DATA_PATH, "w") as f:
                json.dump(data, f, indent=4)

            click.echo("Success.")
        else:
            click.echo(f"\nShift ID {shift_id} not found.")
    except Exception as e:
        click.echo(f"An error occurred: {e}")

    click.pause(info="Press any key to continue...")
    div()
    
    

@click.command(help="Display the README file.")
def readme():
    cd(KORTEX_DIR)
    title()
    with open("README.md", "r") as f:
        for i in f:
            print(i, end="")
            wait()
    print_blank_lines()
    div()
    input("\nPress Enter to continue...")
    clear_screen()
    
    

@click.command(help="Invoke the graphical user interface (GUI).")
def gui():
    """Invokes the graphical user interface (GUI). For a detailed description,
    type `kortex readme`."""
    gui_main()
    
    

cli.add_command(record)
cli.add_command(view)
cli.add_command(delete)
cli.add_command(totals)
cli.add_command(edit)
cli.add_command(readme)
cli.add_command(gui)
cli.add_command(logs)


def main():
    initialize()  # Ensures `data.json` exists
    cli()  # Invoke the Click CLI
    


if __name__ == "__main__":
    main()
