# __main__.py

from kemist.main import main

if __name__ == "__main__":
    main()
