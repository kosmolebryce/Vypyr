# __main__.py

from kortex.main.main import main

if __name__ == "__main__":
    main()
