# TYMYR

## `v0.0.1`


-----


### Description
`tymyr` is a simple stopwatch widget belonging to the `vypyr` utilities library.